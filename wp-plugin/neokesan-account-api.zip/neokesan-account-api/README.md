# neoKesan Account API (WP plugin) — Phase 2

Headless customer-account API for the neoKesan static site. Phase 1 added JWT bearer
authentication, CORS for the static site, and `/profile`, `/orders`, `/dev-token`.
Phase 2 adds **OTP login** (`/otp/send`, `/otp/verify`) — passwordless email login
that issues the same JWTs. Later phases add Google login, then wire up the frontend
account page, cart, and headless checkout.

Version: 0.2.0 · Requires PHP 7.4+

---

## Install

1. Copy the `neokesan-account-api` folder into `wp-content/plugins/` on
   `shop.neokesan.com`.
2. Activate **neoKesan Account API** in the WordPress admin (Plugins → Installed Plugins).
3. Add the constants below to `wp-config.php`.

### wp-config.php constants

```php
// REQUIRED — JWT signing secret. Generate a long random string, e.g.
// `php -r "echo bin2hex(random_bytes(32));"`
define('NEOKESAN_JWT_SECRET', 'replace-with-a-long-random-secret');

// DEV ONLY — enables the /dev-token endpoint used for curl testing below.
// Remove (or set false) in production.
define('NEOKESAN_ACCOUNT_API_DEV', true);
// DEV ONLY — secret value for the X-Neokesan-Dev-Secret header.
define('NEOKESAN_DEV_SECRET', 'replace-with-a-different-long-random-secret');

// Optional — comma-separated override of the allowed origins.
// Defaults: https://neokesan.com, https://www.neokesan.com, localhost dev ports.
// define('NEOKESAN_CORS_ORIGINS', 'https://neokesan.com,http://localhost:5500');
```

If `NEOKESAN_JWT_SECRET` is not set, the plugin falls back to
`JWT_AUTH_SECRET_KEY`, then `SECURE_AUTH_KEY`, then `AUTH_KEY`, then `wp_salt('auth')`.

> **OTP delivery in DEV:** while `NEOKESAN_ACCOUNT_API_DEV` is `true`, `/otp/send`
> echoes the generated code as `dev_code` in the response (and logs it) so the flow
> can be tested before real SMTP is configured. The plugin still attempts `wp_mail()`
> every time. Remove the DEV constants before production.

## Endpoints

All routes are namespaced `/wp-json/neokesan/v1/`. Replace `your-host` with the shop.

| Route | Method | Auth | Purpose |
|---|---|---|---|
| `/otp/send` | POST | none (public) | Request a 6-digit login code by email (rate-limited) |
| `/otp/verify` | POST | none (public) | Verify a code → returns a JWT |
| `/profile` | GET | Bearer token | Fetch current user's profile + grower fields |
| `/profile` | POST | Bearer token | Update profile fields |
| `/orders` | GET | Bearer token | Current user's WooCommerce orders |
| `/dev-token` | POST | `X-Neokesan-Dev-Secret` | **DEV ONLY** — mint a JWT for testing |

### OTP login

```jsonc
// POST /otp/send  {"email": "you@example.com"}
// 200:
{ "status": "code_sent",
  "message": "If this email is registered, a login code has been sent.",
  "expires_in": 600 }

// DEV only — NEOKESAN_ACCOUNT_API_DEV=true adds:
//   "dev_code": "482913",

// POST /otp/verify  {"email": "you@example.com", "code": "482913"}
// 200:
{ "token": "eyJ...", "expires_in": 259200, "user_id": 5, "email": "you@example.com" }
```

- The email does not need to exist: the plugin **find-or-creates** the user
  (username = email local part, role `customer`, random unusable password).
- **Anti-enumeration:** send returns the identical body whether or not the email
  exists, so a caller can't probe which addresses are registered.
- **Rate limits:** 5 send requests per email / 10 per IP per hour (429), 5 verify
  attempts per code (429).
- Codes are stored hashed, expire after 10 minutes, and are single-use.
- The returned JWT is the same bearer token used by `/profile` and `/orders`.

### Profile fields

| JSON key | Notes |
|---|---|
| `first_name`, `last_name` | WP core fields |
| `email` | WP core `user_email`; must be unique (409 if taken) |
| `phone` | meta `neokesan_phone` |
| `dob` | meta `neokesan_dob`; `YYYY-MM-DD`, strict |
| `language` | meta `neokesan_language`; one of English/Hindi/Bengali/Marathi |
| `growing_setup` | meta `neokesan_growing_setup` |
| `crops` | meta `neokesan_crops` |
| `garden_notes` | meta `neokesan_garden_notes` (future use) |

## curl test steps

These work over the command line — no WordPress nonce required, because bearer
tokens bypass cookie checks.

```bash
BASE="https://your-host"

# 1. Mint a dev token for user ID 1 (the admin user).
curl -s -X POST "$BASE/wp-json/neokesan/v1/dev-token" \
  -H "Content-Type: application/json" \
  -H "X-Neokesan-Dev-Secret: replace-with-your-dev-secret" \
  -d '{"user_id":1}'

#    → {"token":"eyJ...","expires_in":259200,"user_id":1,"email":"...","note":"DEV ONLY ..."}

# 2. Read the profile with the token.
TOKEN="paste-token-here"
curl -s "$BASE/wp-json/neokesan/v1/profile" -H "Authorization: Bearer $TOKEN"

# 3. Update a few profile fields.
curl -s -X POST "$BASE/wp-json/neokesan/v1/profile" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"first_name":"Test","language":"English","growing_setup":"DWC / NFT","crops":"basil, mint"}'

# 4. Read orders (returns woocommerce:false gracefully if WC is inactive).
curl -s "$BASE/wp-json/neokesan/v1/orders" -H "Authorization: Bearer $TOKEN"

# 5. OPTIONS preflight (the static site sends this before every cross-origin call).
curl -s -i -X OPTIONS "$BASE/wp-json/neokesan/v1/profile" \
  -H "Origin: https://neokesan.com" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: Authorization, Content-Type"
#    → HTTP/1.1 204 with Access-Control-Allow-Origin: https://neokesan.com etc.
```

### OTP login test (DEV mode)

```bash
# 6. Request a login code (DEV mode echoes dev_code; same 200 body for any email).
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/send" \
  -H "Content-Type: application/json" \
  -d '{"email":"grower@example.com"}'
#    → {"status":"code_sent","message":"...","expires_in":600,"dev_code":"123456",...}

# 7. Verify with a WRONG code → 400 neokesan_otp_invalid.
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/verify" \
  -H "Content-Type: application/json" \
  -d '{"email":"grower@example.com","code":"000000"}'

# 8. Verify with the dev_code → real JWT.
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/verify" \
  -H "Content-Type: application/json" \
  -d '{"email":"grower@example.com","code":"123456"}'
#    → {"token":"eyJ...","expires_in":259200,"user_id":N,"email":"grower@example.com"}

# 9. Use that token on /profile (token was a fresh find-or-create user).
TOKEN="paste-token-here"
curl -s "$BASE/wp-json/neokesan/v1/profile" -H "Authorization: Bearer $TOKEN"
```

Expected failure checks:

```bash
# No token → 401.
curl -s "$BASE/wp-json/neokesan/v1/profile"

# Wrong dev secret → 403.
curl -s -X POST "$BASE/wp-json/neokesan/v1/dev-token" \
  -H "Content-Type: application/json" \
  -H "X-Neokesan-Dev-Secret: wrong" \
  -d '{"user_id":1}'

# Missing/invalid OTP email → 400 (same for everyone).
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/send" \
  -H "Content-Type: application/json" \
  -d '{"email":"not-an-email"}'

# No pending code → 400 neokesan_otp_no_code.
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/verify" \
  -H "Content-Type: application/json" \
  -d '{"email":"nobody@example.com","code":"000000"}'

# Rate limit: 5+ sends on the same email in an hour → 429 neokesan_otp_limit.
for i in 1 2 3 4 5 6; do
  curl -s -o /dev/null -w "%{http_code}\n" -X POST "$BASE/wp-json/neokesan/v1/otp/send" \
    -H "Content-Type: application/json" -d '{"email":"grower@example.com"}'
done
#    → 200 200 200 200 200 429
```

## Troubleshooting

- **401 on dev-token with correct secret**: confirm `NEOKESAN_ACCOUNT_API_DEV` is `true`
  and the plugin is active. If the route does not exist, WordPress returns a 404.
- **`Access-Control-Allow-Origin` missing**: the origin must be in the allowlist
  exactly (scheme + host + port, no trailing slash). Check your localhost port matches.
- **PHP fatal on plugin activation**: confirm PHP ≥ 7.4 (e.g. `php -v` on the server).
- **Token works in curl but not the browser**: the browser sends a preflight first;
  confirm step 5 passes. Also ensure the secret in `wp-config.php` did not change
  after minting tokens.
- **`dev_code` missing from `/otp/send`**: confirm `NEOKESAN_ACCOUNT_API_DEV` is
  `true` and the plugin re-activated after the update (or hard-refresh — transients
  are per-site, not per-request).
- **OTP email never arrives**: `wp_mail()` needs a working SMTP setup. Until then,
  use `dev_code` from the response / the `error_log`. The API never fails a send
  request just because the mail failed.
- **429 on `/otp/send`**: you hit the 5/hr-per-email or 10/hr-per-IP limit. Wait an
  hour or use a different email/IP; this is expected anti-spam behaviour.

## Roadmap

Phase 2 (this): OTP send/verify (email → SMS later). Phase 3: Google sign-in.
Phase 4: wire the frontend `account.html`. Phase 5: cart via Store API.
Phase 6: headless checkout (Razorpay). Phase 7: hardening. See
`docs/ACCOUNT-SYSTEM-PLAN.md` at the repo root for the full plan.
