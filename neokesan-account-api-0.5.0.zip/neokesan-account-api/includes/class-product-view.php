<?php
/**
 * POST /neokesan/v1/product-view — records product page views for signed-in users,
 * feeding the admin-only analytics dashboard.
 *
 * @package neokesan-account-api
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Product-view endpoint.
 */
class Neokesan_Product_View {

	/**
	 * User-meta key for the product-view log.
	 *
	 * @var string
	 */
	const META_VIEWS = 'neokesan_product_views';

	/**
	 * Cap on stored events per user — bound meta growth, drop the oldest.
	 *
	 * @var int
	 */
	const MAX_VIEWS = 500;

	/**
	 * Register the product-view route.
	 *
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			'neokesan/v1',
			'/product-view',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'record_view' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_login' ),
				),
			)
		);
	}

	/**
	 * POST handler — append one view event to the user's meta array.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function record_view( $request ) {
		$user_id = get_current_user_id();

		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : array();
		$key    = isset( $params['key'] ) ? sanitize_key( $params['key'] ) : '';

		$products = Neokesan_Quiz::PRODUCTS;
		if ( ! isset( $products[ $key ] ) ) {
			return new WP_Error(
				'neokesan_bad_product',
				'Unknown product.',
				array( 'status' => 400 )
			);
		}

		$views   = get_user_meta( $user_id, self::META_VIEWS, true );
		$views   = is_array( $views ) ? $views : array();
		$views[] = array(
			'key'       => $key,
			'name'      => $products[ $key ]['name'],
			'viewed_at' => gmdate( 'Y-m-d\TH:i:s\Z' ),
		);

		// Bound growth: drop the oldest events once past the cap.
		if ( count( $views ) > self::MAX_VIEWS ) {
			$views = array_slice( $views, -self::MAX_VIEWS );
		}

		update_user_meta( $user_id, self::META_VIEWS, $views );

		return rest_ensure_response(
			array(
				'saved'       => true,
				'views_count' => count( $views ),
			)
		);
	}
}
