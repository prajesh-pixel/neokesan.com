<?php
/**
 * GET /neokesan/v1/admin/stats + /neokesan/v1/admin/users — admin-only analytics
 * for the neoKesan dashboard. Product views, quiz attempts, and buy-on-Amazon
 * clicks, both aggregated and per-user. Gated by the manage_options capability.
 *
 * @package neokesan-account-api
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin analytics endpoints.
 */
class Neokesan_Admin {

	/**
	 * Register the admin routes.
	 *
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			'neokesan/v1',
			'/admin/stats',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'stats' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_admin' ),
				),
			)
		);

		register_rest_route(
			'neokesan/v1',
			'/admin/users',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'users' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_admin' ),
				),
			)
		);
	}

	/**
	 * GET handler — aggregate overview across all users with any activity.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function stats( $request ) {
		$user_ids = self::active_user_ids();
		$counts   = count_users();

		$stats = array(
			'users_total'        => (int) $counts['total_users'],
			'active_users'       => count( $user_ids ),
			'views_total'        => 0,
			'views_by_product'   => array(),
			'quiz_attempts_total'=> 0,
			'quiz_users'         => 0,
			'picks_total'        => 0,
		);

		foreach ( $user_ids as $user_id ) {
			$views    = self::meta( $user_id, Neokesan_Product_View::META_VIEWS );
			$attempts = self::meta( $user_id, Neokesan_Quiz::META_ATTEMPTS );
			$picks    = self::meta( $user_id, Neokesan_Quiz::META_PICKS );

			foreach ( $views as $view ) {
				$key = $view['key'];
				$stats['views_total']++;
				if ( ! isset( $stats['views_by_product'][ $key ] ) ) {
					$stats['views_by_product'][ $key ] = 0;
				}
				$stats['views_by_product'][ $key ]++;
			}

			if ( $attempts ) {
				$stats['quiz_users']++;
				$stats['quiz_attempts_total'] += count( $attempts );
			}

			$stats['picks_total'] += count( $picks );
		}

		return rest_ensure_response( $stats );
	}

	/**
	 * GET handler — one object per user with any activity.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function users( $request ) {
		$rows = array();

		foreach ( self::active_user_ids() as $user_id ) {
			$wp_user = get_userdata( $user_id );
			if ( ! $wp_user ) {
				continue;
			}

			$views    = self::meta( $user_id, Neokesan_Product_View::META_VIEWS );
			$attempts = self::meta( $user_id, Neokesan_Quiz::META_ATTEMPTS );
			$picks    = self::meta( $user_id, Neokesan_Quiz::META_PICKS );

			$by_product = array();
			foreach ( $views as $view ) {
				$key = $view['key'];
				if ( ! isset( $by_product[ $key ] ) ) {
					$by_product[ $key ] = 0;
				}
				$by_product[ $key ]++;
			}

			$rows[] = array(
				'user_id'    => $user_id,
				'email'      => $wp_user->user_email,
				'name'       => $wp_user->display_name,
				'created_at' => self::to_iso( $wp_user->user_registered ),
				'views'      => array(
					'total'      => count( $views ),
					'by_product' => $by_product,
					'events'     => $views,
				),
				'quiz'       => array(
					'attempts' => $attempts,
					'picks'    => $picks,
				),
			);
		}

		return rest_ensure_response( $rows );
	}

	/**
	 * All user IDs that have any recorded activity (views, attempts, or picks).
	 *
	 * @return int[]
	 */
	private static function active_user_ids() {
		$ids = get_users(
			array(
				'fields'     => 'ID',
				'meta_query' => array(
					'relation' => 'OR',
					array( 'key' => Neokesan_Product_View::META_VIEWS, 'compare' => 'EXISTS' ),
					array( 'key' => Neokesan_Quiz::META_ATTEMPTS, 'compare' => 'EXISTS' ),
					array( 'key' => Neokesan_Quiz::META_PICKS, 'compare' => 'EXISTS' ),
				),
			)
		);

		return array_map( 'absint', $ids );
	}

	/**
	 * Read one user-meta array, defaulting to empty.
	 *
	 * @param int    $user_id User ID.
	 * @param string $key     Meta key.
	 * @return array
	 */
	private static function meta( $user_id, $key ) {
		$value = get_user_meta( $user_id, $key, true );
		return is_array( $value ) ? $value : array();
	}

	/**
	 * WP MySQL datetime (UTC, naive) → ISO 8601 Z.
	 *
	 * @param string $mysql_dt 'Y-m-d H:i:s' from user_registered.
	 * @return string
	 */
	private static function to_iso( $mysql_dt ) {
		return gmdate( 'Y-m-d\TH:i:s\Z', strtotime( $mysql_dt . ' UTC' ) );
	}
}
