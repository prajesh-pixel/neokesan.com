<?php
/**
 * Product catalog — CRUD for the {prefix}neokesan_products table, the public
 * catalog endpoints, and the admin-only management endpoints (create / update /
 * delete / image upload). Every product's full detail object lives in the `data`
 * LONGTEXT column as JSON; name/status/asin are mirrored into dedicated columns
 * for cheap listing and the quiz/product-view registry.
 *
 * @package neokesan-account-api
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Catalog storage + endpoints.
 */
class Neokesan_Products {

	/**
	 * Schema version. Bump when the CREATE TABLE changes so maybe_upgrade()
	 * re-runs dbDelta (admin_init hook, guarded by the option below).
	 *
	 * @var int
	 */
	const DB_VERSION = 1;

	/**
	 * Option that records the last-applied schema version.
	 *
	 * @var string
	 */
	const DB_OPTION = 'neokesan_products_db_version';

	/**
	 * Subdirectory (under wp-content/uploads) that hosted product images live in.
	 *
	 * @var string
	 */
	const IMAGE_SUBDIR = 'neokesan-products';

	/**
	 * Cap on a single uploaded image, in bytes.
	 *
	 * @var int
	 */
	const MAX_IMAGE_BYTES = 2097152; // 2 MB.

	/**
	 * MIME whitelist — SVG is deliberately excluded (stored XSS on the shop origin).
	 *
	 * @var string[]
	 */
	const MIME_EXT = array(
		'image/jpeg' => 'jpg',
		'image/png'  => 'png',
		'image/webp' => 'webp',
		'image/gif'  => 'gif',
	);

	/**
	 * Valid product statuses.
	 *
	 * @var string[]
	 */
	const VALID_STATUSES = array( 'active', 'draft', 'archived' );

	/**
	 * Request-lifetime cache of the active registry (key → summary). Null until
	 * first read; invalidated on every write so a single request never serves
	 * stale data after a mutation.
	 *
	 * @var array|null
	 */
	private static $registry = null;

	/**
	 * Allowlisted top-level keys of the `data` JSON object.
	 *
	 * @var string[]
	 */
	const DATA_KEYS = array(
		'name', 'family', 'category', 'badge', 'word', 'accent', 'soft',
		'price', 'description', 'formula', 'variants', 'features',
		'guide', 'composition', 'images',
	);

	/**
	 * Table name (prefixed).
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'neokesan_products';
	}

	/**
	 * Create the table via dbDelta. Called on plugin activation AND via
	 * admin_init (activation does not re-fire on an already-active plugin, so the
	 * version-option check in maybe_upgrade() is the upgrade safety net).
	 *
	 * @return void
	 */
	public static function maybe_create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$table   = self::table();

		// dbDelta quirks that silently break it: two spaces after PRIMARY KEY,
		// KEY/UNIQUE KEY (never INDEX), no trailing comma, id first, and column
		// type strings byte-identical across runs.
		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_key VARCHAR(60) NOT NULL,
			name VARCHAR(120) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			asin VARCHAR(32) NOT NULL DEFAULT '',
			data LONGTEXT NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY product_key (product_key)
		) {$charset};";

		dbDelta( $sql );
	}

	/**
	 * Apply schema upgrades when needed. Cheap on every admin load: returns
	 * immediately once the recorded version matches.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( (int) get_option( self::DB_OPTION, 0 ) >= self::DB_VERSION ) {
			return;
		}
		self::maybe_create_table();
		self::seed_defaults_if_empty();
		update_option( self::DB_OPTION, self::DB_VERSION );
	}

	/**
	 * Seed the full catalog from the shipped JSON the first time the table is
	 * empty. Zip → activate alone populates it; no script step required.
	 *
	 * @return void
	 */
	public static function seed_defaults_if_empty() {
		global $wpdb;
		$table = self::table();
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
		if ( $count > 0 ) {
			return;
		}

		$file = NEOKESAN_ACCOUNT_API_DIR . 'includes/data/products-seed.json';
		if ( ! file_exists( $file ) ) {
			return;
		}
		$rows = json_decode( (string) file_get_contents( $file ), true );
		if ( ! is_array( $rows ) ) {
			return;
		}

		foreach ( $rows as $row ) {
			if ( empty( $row['product_key'] ) || empty( $row['data'] ) || ! is_array( $row['data'] ) ) {
				continue;
			}
			$key  = sanitize_key( $row['product_key'] );
			$name = isset( $row['data']['name'] ) ? self::truncate( sanitize_text_field( (string) $row['data']['name'] ), 120 ) : '';
			if ( '' === $key || '' === $name ) {
				continue;
			}

			$wpdb->insert(
				$table,
				array(
					'product_key' => $key,
					'name'        => $name,
					'status'      => isset( $row['status'] ) && in_array( $row['status'], self::VALID_STATUSES, true ) ? $row['status'] : 'active',
					'asin'        => self::sanitize_asin( isset( $row['asin'] ) ? $row['asin'] : '' ),
					'data'        => wp_json_encode( $row['data'] ),
					'created_at'  => current_time( 'mysql' ),
					'updated_at'  => current_time( 'mysql' ),
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
			);
		}

		self::invalidate();
	}

	/**
	 * All rows, optionally filtered by status, ordered by name. `data` is decoded
	 * defensively — a corrupt row yields an empty array, never a fatal.
	 *
	 * @param string $status Optional status filter.
	 * @return object[]
	 */
	public static function get_all( $status = '' ) {
		global $wpdb;
		$table = self::table();

		if ( $status ) {
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status = %s ORDER BY name ASC", $status ) );
		} else {
			$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY name ASC" );
		}

		$products = array();
		foreach ( (array) $rows as $row ) {
			$row->data = self::decode_data( $row->data );
			$products[] = $row;
		}
		return $products;
	}

	/**
	 * One row by key, or null. `data` decoded as an array.
	 *
	 * @param string $key Product key.
	 * @return object|null
	 */
	public static function get_by_key( $key ) {
		global $wpdb;
		$table = self::table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE product_key = %s LIMIT 1", $key ) );
		if ( $row ) {
			$row->data = self::decode_data( $row->data );
		}
		return $row;
	}

	/**
	 * Whether a product with this key exists.
	 *
	 * @param string $key Product key.
	 * @return bool
	 */
	public static function exists( $key ) {
		global $wpdb;
		$table = self::table();
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE product_key = %s LIMIT 1", $key ) );
	}

	/**
	 * Insert a new product. Duplicate key → WP_Error 409.
	 *
	 * @param string $key   Product key (slug).
	 * @param string $name  Short product name.
	 * @param string $asin  Amazon ASIN.
	 * @param string $status Active|draft|archived.
	 * @param array  $data  Sanitized full detail object.
	 * @return object|WP_Error
	 */
	public static function insert( $key, $name, $asin, $status, $data ) {
		global $wpdb;
		$table = self::table();

		if ( self::exists( $key ) ) {
			return new WP_Error(
				'neokesan_slug_taken',
				'A product with that key already exists.',
				array( 'status' => 409 )
			);
		}

		$result = $wpdb->insert(
			$table,
			array(
				'product_key' => $key,
				'name'        => $name,
				'status'      => $status,
				'asin'        => $asin,
				'data'        => wp_json_encode( $data ),
				'created_at'  => current_time( 'mysql' ),
				'updated_at'  => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $result ) {
			return new WP_Error(
				'neokesan_db_error',
				'Could not save the product.',
				array( 'status' => 500 )
			);
		}

		// Every product gets a permanent QR slug the moment it exists, so a product
		// added years from now is printable without any extra step.
		Neokesan_QR::ensure( $key );
		self::invalidate();
		return self::get_by_key( $key );
	}

	/**
	 * Update column fields on an existing product. Pass only the columns you want
	 * to change (name/status/asin/data). Missing key → WP_Error 404.
	 *
	 * @param string $key    Product key.
	 * @param array  $fields Column → value map.
	 * @return object|WP_Error
	 */
	public static function update_by_key( $key, $fields ) {
		global $wpdb;
		$table = self::table();

		if ( ! self::exists( $key ) ) {
			return new WP_Error(
				'neokesan_not_found',
				'Product not found.',
				array( 'status' => 404 )
			);
		}

		$fields['updated_at'] = current_time( 'mysql' );
		$result               = $wpdb->update(
			$table,
			$fields,
			array( 'product_key' => $key ),
			array_fill( 0, count( $fields ), '%s' )
		);

		if ( false === $result ) {
			return new WP_Error(
				'neokesan_db_error',
				'Could not update the product.',
				array( 'status' => 500 )
			);
		}

		self::invalidate();
		return self::get_by_key( $key );
	}

	/**
	 * Hard-delete a product, cleaning up any hosted images first.
	 *
	 * @param string $key Product key.
	 * @return true|WP_Error
	 */
	public static function delete_by_key( $key ) {
		global $wpdb;
		$table = self::table();

		$row = self::get_by_key( $key );
		if ( ! $row ) {
			return new WP_Error(
				'neokesan_not_found',
				'Product not found.',
				array( 'status' => 404 )
			);
		}

		self::delete_images( $row->data );

		$result = $wpdb->delete( $table, array( 'product_key' => $key ), array( '%s' ) );
		if ( false === $result ) {
			return new WP_Error(
				'neokesan_db_error',
				'Could not delete the product.',
				array( 'status' => 500 )
			);
		}

		// Retire, never delete — the slug has to stay in the history so it can never
		// be reissued to a different product, and any code already printed has to
		// keep resolving.
		Neokesan_QR::retire( $key );
		self::invalidate();
		return true;
	}

	/**
	 * Active-product registry consumed by the quiz and product-view endpoints:
	 * key → {name (display), asin, url, page}. URL/page are derived, never stored.
	 * Built once per request and invalidated on any write.
	 *
	 * @return array
	 */
	public static function registry() {
		if ( null === self::$registry ) {
			self::$registry = array();
			foreach ( self::get_all( 'active' ) as $row ) {
				self::$registry[ $row->product_key ] = array(
					'name' => self::display_name( $row ),
					'asin' => $row->asin,
					'url'  => self::amazon_url( $row->asin ),
					'page' => 'product.html?key=' . rawurlencode( $row->product_key ),
				);
			}
		}
		return self::$registry;
	}

	/**
	 * Drop the registry cache (call after any write).
	 *
	 * @return void
	 */
	public static function invalidate() {
		self::$registry = null;
	}

	/**
	 * Sanitize + validate a `data` object on write. Unknown top-level keys are
	 * rejected (400) rather than silently dropped so the admin form can't drift
	 * from the schema. Returns the cleaned array or a WP_Error.
	 *
	 * @param mixed $data Raw data object.
	 * @return array|WP_Error
	 */
	public static function sanitize_data( $data ) {
		if ( ! is_array( $data ) ) {
			return new WP_Error(
				'neokesan_bad_data',
				'Product data must be an object.',
				array( 'status' => 400 )
			);
		}

		foreach ( array_keys( $data ) as $key ) {
			if ( ! in_array( $key, self::DATA_KEYS, true ) ) {
				return new WP_Error(
					'neokesan_invalid_field',
					'Unknown field: ' . esc_html( $key ) . '.',
					array( 'status' => 400 )
				);
			}
		}

		$clean = array(
			'name'        => isset( $data['name'] ) ? self::truncate( sanitize_text_field( (string) $data['name'] ), 120 ) : '',
			'family'      => isset( $data['family'] ) ? sanitize_text_field( (string) $data['family'] ) : '',
			'category'    => isset( $data['category'] ) ? sanitize_text_field( (string) $data['category'] ) : '',
			'badge'       => isset( $data['badge'] ) ? sanitize_text_field( (string) $data['badge'] ) : '',
			'word'        => isset( $data['word'] ) ? sanitize_text_field( (string) $data['word'] ) : '',
			'accent'      => self::sanitize_color( isset( $data['accent'] ) ? $data['accent'] : '' ),
			'soft'        => self::sanitize_color( isset( $data['soft'] ) ? $data['soft'] : '' ),
			'price'       => self::sanitize_price( isset( $data['price'] ) ? $data['price'] : '' ),
			'description' => isset( $data['description'] ) ? wp_kses( (string) $data['description'], self::allowed_html() ) : '',
			'formula'     => isset( $data['formula'] ) ? sanitize_text_field( (string) $data['formula'] ) : '',
			'variants'    => self::sanitize_string_list( isset( $data['variants'] ) ? $data['variants'] : array(), 8 ),
			'features'    => self::sanitize_features( isset( $data['features'] ) ? $data['features'] : array() ),
			'guide'       => self::sanitize_guide( isset( $data['guide'] ) ? $data['guide'] : array() ),
			'composition' => self::sanitize_composition( isset( $data['composition'] ) ? $data['composition'] : null ),
			'images'      => self::sanitize_images( isset( $data['images'] ) ? $data['images'] : array() ),
		);

		if ( '' === $clean['name'] ) {
			return new WP_Error(
				'neokesan_name_required',
				'Product name is required.',
				array( 'status' => 400 )
			);
		}

		return $clean;
	}

	/**
	 * Register the product routes.
	 *
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			'neokesan/v1',
			'/products',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'list_public' ),
					'permission_callback' => '__return_true',
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'create' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_admin' ),
				),
			)
		);

		register_rest_route(
			'neokesan/v1',
			'/products/(?P<key>[a-zA-Z0-9_-]+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'get_public' ),
					'permission_callback' => '__return_true',
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( __CLASS__, 'update' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_admin' ),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'delete' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_admin' ),
				),
			)
		);

		register_rest_route(
			'neokesan/v1',
			'/products/(?P<key>[a-zA-Z0-9_-]+)/image',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'upload_image' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_admin' ),
				),
			)
		);

		register_rest_route(
			'neokesan/v1',
			'/admin/products',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'list_admin' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_admin' ),
				),
			)
		);
	}

	/**
	 * GET /products — public list of active products.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function list_public( $request ) {
		$products = array();
		foreach ( self::get_all( 'active' ) as $row ) {
			$products[] = self::public_payload( $row );
		}
		return rest_ensure_response( $products );
	}

	/**
	 * GET /products/{key} — one active product.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_public( $request ) {
		$key = sanitize_key( (string) $request['key'] );
		$row = self::get_by_key( $key );
		if ( ! $row || 'active' !== $row->status ) {
			return new WP_Error(
				'neokesan_not_found',
				'Product not found.',
				array( 'status' => 404 )
			);
		}
		return rest_ensure_response( self::public_payload( $row ) );
	}

	/**
	 * GET /admin/products — all statuses for the dashboard list.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function list_admin( $request ) {
		$products = array();
		foreach ( self::get_all() as $row ) {
			$products[] = self::admin_payload( $row );
		}
		return rest_ensure_response( $products );
	}

	/**
	 * POST /products — create. Body {key, status?, asin?, data}.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create( $request ) {
		$params = self::request_params( $request );

		$key    = isset( $params['key'] ) ? sanitize_key( (string) $params['key'] ) : '';
		$status = self::sanitize_status( isset( $params['status'] ) ? $params['status'] : 'active' );
		$asin   = self::sanitize_asin( isset( $params['asin'] ) ? $params['asin'] : '' );
		$data   = self::sanitize_data( isset( $params['data'] ) ? $params['data'] : array() );

		if ( is_wp_error( $data ) ) {
			return $data;
		}
		if ( '' === $key ) {
			return new WP_Error(
				'neokesan_key_required',
				'A product key is required.',
				array( 'status' => 400 )
			);
		}
		// Keys become URLs + price-data keys, so they must stay slug-safe.
		if ( ! preg_match( '/^[a-z0-9_-]+$/', $key ) ) {
			return new WP_Error(
				'neokesan_bad_key',
				'Product key may only contain lowercase letters, numbers, dashes and underscores.',
				array( 'status' => 400 )
			);
		}

		$row = self::insert( $key, $data['name'], $asin, $status, $data );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		$response = rest_ensure_response( self::admin_payload( $row ) );
		$response->set_status( 201 );
		return $response;
	}

	/**
	 * PUT /products/{key} — partial update. Body {data?, asin?, status?}.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function update( $request ) {
		$key    = sanitize_key( (string) $request['key'] );
		$params = self::request_params( $request );

		if ( ! self::exists( $key ) ) {
			return new WP_Error(
				'neokesan_not_found',
				'Product not found.',
				array( 'status' => 404 )
			);
		}

		$fields = array();
		if ( isset( $params['data'] ) && is_array( $params['data'] ) ) {
			$data = self::sanitize_data( $params['data'] );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			$fields['name'] = $data['name'];
			$fields['data'] = wp_json_encode( $data );
		}
		if ( isset( $params['status'] ) ) {
			$fields['status'] = self::sanitize_status( $params['status'] );
		}
		if ( isset( $params['asin'] ) ) {
			$fields['asin'] = self::sanitize_asin( $params['asin'] );
		}

		if ( ! $fields ) {
			return new WP_Error(
				'neokesan_bad_request',
				'Nothing to update.',
				array( 'status' => 400 )
			);
		}

		$row = self::update_by_key( $key, $fields );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		return rest_ensure_response( self::admin_payload( $row ) );
	}

	/**
	 * DELETE /products/{key} — hard delete + image cleanup.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function delete( $request ) {
		$key    = sanitize_key( (string) $request['key'] );
		$result = self::delete_by_key( $key );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response( array( 'deleted' => true, 'key' => $key ) );
	}

	/**
	 * POST /products/{key}/image — base64 image upload. Body {mime, data}.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function upload_image( $request ) {
		$key = sanitize_key( (string) $request['key'] );
		if ( ! self::exists( $key ) ) {
			return new WP_Error(
				'neokesan_not_found',
				'Product not found.',
				array( 'status' => 404 )
			);
		}

		$params = self::request_params( $request );
		$mime   = isset( $params['mime'] ) ? strtolower( trim( (string) $params['mime'] ) ) : '';
		$data   = isset( $params['data'] ) ? (string) $params['data'] : '';

		if ( ! isset( self::MIME_EXT[ $mime ] ) ) {
			return new WP_Error(
				'neokesan_bad_image',
				'Unsupported image type. Use JPEG, PNG, WebP or GIF.',
				array( 'status' => 400 )
			);
		}

		// Strict base64 — the client strips the data:image/...;base64, prefix.
		$bytes = base64_decode( $data, true );
		if ( false === $bytes || '' === $bytes ) {
			return new WP_Error(
				'neokesan_bad_image',
				'Image data is not valid base64.',
				array( 'status' => 400 )
			);
		}
		if ( strlen( $bytes ) > self::MAX_IMAGE_BYTES ) {
			return new WP_Error(
				'neokesan_image_too_large',
				'Image must be 2 MB or smaller.',
				array( 'status' => 413 )
			);
		}

		// Content-sniff: refuse a mismatch (e.g. text masquerading as PNG).
		if ( function_exists( 'finfo_open' ) ) {
			$finfo = finfo_open( FILEINFO_MIME_TYPE );
			if ( $finfo ) {
				$sniffed = finfo_buffer( $finfo, $bytes );
				finfo_close( $finfo );
				if ( $sniffed && $sniffed !== $mime ) {
					return new WP_Error(
						'neokesan_bad_image',
						'Image content does not match its declared type.',
						array( 'status' => 400 )
					);
				}
			}
		}

		$uploads = wp_upload_dir( self::IMAGE_SUBDIR );
		if ( ! empty( $uploads['error'] ) ) {
			return new WP_Error(
				'neokesan_upload_failed',
				'The upload directory is not writable.',
				array( 'status' => 500 )
			);
		}

		$ext      = self::MIME_EXT[ $mime ];
		$filename = $key . '-' . gmdate( 'YmdHis' ) . '-' . wp_rand( 1000, 9999 ) . '.' . $ext;
		$filename = wp_unique_filename( $uploads['path'], $filename );
		$written  = wp_upload_bits( $filename, null, $bytes, self::IMAGE_SUBDIR );

		if ( ! empty( $written['error'] ) ) {
			return new WP_Error(
				'neokesan_upload_failed',
				$written['error'],
				array( 'status' => 500 )
			);
		}

		$row   = self::get_by_key( $key );
		$d     = $row->data;
		if ( ! isset( $d['images'] ) || ! is_array( $d['images'] ) ) {
			$d['images'] = array();
		}
		$d['images'][] = $written['url'];
		$d['images']   = self::sanitize_images( $d['images'] );

		$updated = self::update_by_key( $key, array( 'data' => wp_json_encode( $d ) ) );
		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		return rest_ensure_response(
			array(
				'url'    => $written['url'],
				'images' => $d['images'],
			)
		);
	}

	/**
	 * Public payload for a row.
	 *
	 * @param object $row Row.
	 * @return array
	 */
	private static function public_payload( $row ) {
		return array(
			'slug'       => $row->product_key,
			'name'       => self::short_name( $row ),
			'asin'       => $row->asin,
			'page'       => 'product.html?key=' . rawurlencode( $row->product_key ),
			'amazonUrl'  => self::amazon_url( $row->asin ),
			'data'       => $row->data,
			'updated_at' => self::to_iso( $row->updated_at ),
		);
	}

	/**
	 * Admin payload for a row (includes id + status + created_at).
	 *
	 * @param object $row Row.
	 * @return array
	 */
	private static function admin_payload( $row ) {
		return array(
			'id'         => (int) $row->id,
			'slug'       => $row->product_key,
			'name'       => self::short_name( $row ),
			'status'     => $row->status,
			'asin'       => $row->asin,
			'data'       => $row->data,
			'created_at' => self::to_iso( $row->created_at ),
			'updated_at' => self::to_iso( $row->updated_at ),
		);
	}

	/**
	 * Decode a data column value; always returns an array.
	 *
	 * @param string $json JSON string.
	 * @return array
	 */
	private static function decode_data( $json ) {
		$data = json_decode( (string) $json, true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Display name = short name + family, e.g. "NeoBloom X1, X2 & X3".
	 *
	 * @param object $row Row.
	 * @return string
	 */
	private static function display_name( $row ) {
		$name   = self::short_name( $row );
		$family = isset( $row->data['family'] ) ? trim( (string) $row->data['family'] ) : '';
		return $name . ( '' !== $family ? ' ' . $family : '' );
	}

	/**
	 * Short name for a row (data.name or the column).
	 *
	 * @param object $row Row.
	 * @return string
	 */
	private static function short_name( $row ) {
		if ( isset( $row->data['name'] ) && '' !== trim( (string) $row->data['name'] ) ) {
			return trim( (string) $row->data['name'] );
		}
		return trim( (string) $row->name );
	}

	/**
	 * Amazon.in URL derived from an ASIN ('' → empty URL).
	 *
	 * @param string $asin ASIN.
	 * @return string
	 */
	private static function amazon_url( $asin ) {
		return $asin ? 'https://www.amazon.in/dp/' . $asin : '';
	}

	/**
	 * Strip + uppercase an ASIN.
	 *
	 * @param mixed $asin Raw ASIN.
	 * @return string
	 */
	private static function sanitize_asin( $asin ) {
		return strtoupper( substr( preg_replace( '/[^A-Za-z0-9]/', '', (string) $asin ), 0, 32 ) );
	}

	/**
	 * Normalize a status; anything invalid falls back to 'active'.
	 *
	 * @param mixed $status Raw status.
	 * @return string
	 */
	private static function sanitize_status( $status ) {
		$status = sanitize_key( (string) $status );
		return in_array( $status, self::VALID_STATUSES, true ) ? $status : 'active';
	}

	/**
	 * JSON body of a request (always an array).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	private static function request_params( $request ) {
		$params = $request->get_json_params();
		return is_array( $params ) ? $params : array();
	}

	/**
	 * Text truncated to a byte-safe character length.
	 *
	 * @param string $value Value.
	 * @param int    $max   Max characters.
	 * @return string
	 */
	private static function truncate( $value, $max ) {
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( (string) $value, 0, $max );
		}
		return substr( (string) $value, 0, $max );
	}

	/**
	 * Inline-HTML allowlist for fields that historically contain markup.
	 *
	 * @return array
	 */
	private static function allowed_html() {
		return array(
			'strong' => array(),
			'b'      => array(),
			'i'      => array(),
			'em'     => array(),
			'br'     => array(),
			'a'      => array( 'href' => true, 'target' => true, 'rel' => true ),
		);
	}

	/**
	 * Empty, or a lowercase #hex color (3–8 digits).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	private static function sanitize_color( $value ) {
		$value = strtolower( trim( (string) $value ) );
		if ( '' === $value ) {
			return '';
		}
		return preg_match( '/^#[0-9a-f]{3,8}$/', $value ) ? $value : '';
	}

	/**
	 * Empty, or a non-negative numeric string (kept as a string so the frontend
	 * can render ₹ and overlay live prices).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	private static function sanitize_price( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}
		if ( ! is_numeric( $value ) || (float) $value < 0 ) {
			return '';
		}
		return $value;
	}

	/**
	 * Plain-text list, capped in length.
	 *
	 * @param mixed $items Raw items.
	 * @param int   $max   Max entries.
	 * @return string[]
	 */
	private static function sanitize_string_list( $items, $max ) {
		$out = array();
		foreach ( (array) $items as $item ) {
			if ( is_array( $item ) || is_object( $item ) ) {
				continue;
			}
			$out[] = sanitize_text_field( (string) $item );
			if ( count( $out ) >= $max ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Feature pairs [title, body], capped at 8.
	 *
	 * @param mixed $features Raw features.
	 * @return array[]
	 */
	private static function sanitize_features( $features ) {
		$out = array();
		foreach ( (array) $features as $feature ) {
			if ( ! is_array( $feature ) || count( $feature ) < 2 ) {
				continue;
			}
			$out[] = array(
				sanitize_text_field( (string) $feature[0] ),
				wp_kses( (string) $feature[1], self::allowed_html() ),
			);
			if ( count( $out ) >= 8 ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Guide object → normalized {hydro:[], soil:[]}, each stage
	 * {label, tds, steps[], tdsPanel:[{range,label}]}.
	 *
	 * @param mixed $guide Raw guide.
	 * @return array
	 */
	private static function sanitize_guide( $guide ) {
		$clean = array( 'hydro' => array(), 'soil' => array() );
		foreach ( array( 'hydro', 'soil' ) as $mode ) {
			$stages = isset( $guide[ $mode ] ) && is_array( $guide[ $mode ] ) ? $guide[ $mode ] : array();
			foreach ( $stages as $stage ) {
				if ( ! is_array( $stage ) ) {
					continue;
				}
				$clean[ $mode ][] = array(
					'label'    => isset( $stage['label'] ) ? sanitize_text_field( (string) $stage['label'] ) : '',
					'tds'      => isset( $stage['tds'] ) ? sanitize_text_field( (string) $stage['tds'] ) : '',
					'steps'    => self::sanitize_html_list( isset( $stage['steps'] ) ? $stage['steps'] : array(), 40 ),
					'tdsPanel' => self::sanitize_tds_panel( isset( $stage['tdsPanel'] ) ? $stage['tdsPanel'] : array() ),
				);
			}
		}
		return $clean;
	}

	/**
	 * TDS panel rows {range, label}, capped at 6.
	 *
	 * @param mixed $panel Raw panel.
	 * @return array[]
	 */
	private static function sanitize_tds_panel( $panel ) {
		$out = array();
		foreach ( (array) $panel as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$out[] = array(
				'range' => isset( $item['range'] ) ? sanitize_text_field( (string) $item['range'] ) : '',
				'label' => isset( $item['label'] ) ? sanitize_text_field( (string) $item['label'] ) : '',
			);
			if ( count( $out ) >= 6 ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Guide steps / list items that may contain inline HTML, capped in length.
	 *
	 * @param mixed $items Raw items.
	 * @param int   $max   Max entries.
	 * @return string[]
	 */
	private static function sanitize_html_list( $items, $max ) {
		$out = array();
		foreach ( (array) $items as $item ) {
			if ( is_array( $item ) || is_object( $item ) ) {
				continue;
			}
			$out[] = wp_kses( (string) $item, self::allowed_html() );
			if ( count( $out ) >= $max ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Composition parts, capped at 12. Each id is interpolated into
	 * showComp('…'), so anything but [a-z0-9_-] is rejected (injection hazard).
	 * Missing/empty composition → null (folix case).
	 *
	 * @param mixed $composition Raw composition.
	 * @return array|null
	 */
	private static function sanitize_composition( $composition ) {
		if ( null === $composition || false === $composition || '' === $composition ) {
			return null;
		}
		if ( ! is_array( $composition ) ) {
			return null;
		}

		$out = array();
		foreach ( $composition as $part ) {
			if ( ! is_array( $part ) ) {
				continue;
			}
			$id = isset( $part['id'] ) ? sanitize_key( (string) $part['id'] ) : '';
			if ( ! preg_match( '/^[a-z0-9_-]+$/', $id ) ) {
				continue;
			}

			$elements = array();
			foreach ( (array) ( isset( $part['elements'] ) ? $part['elements'] : array() ) as $el ) {
				if ( ! is_array( $el ) || count( $el ) < 2 ) {
					continue;
				}
				$elements[] = array(
					sanitize_text_field( (string) $el[0] ),
					sanitize_text_field( (string) $el[1] ),
				);
				if ( count( $elements ) >= 20 ) {
					break;
				}
			}

			$out[] = array(
				'id'         => $id,
				'name'       => isset( $part['name'] ) ? sanitize_text_field( (string) $part['name'] ) : '',
				'desc'       => isset( $part['desc'] ) ? sanitize_text_field( (string) $part['desc'] ) : '',
				'note'       => isset( $part['note'] ) ? wp_kses( (string) $part['note'], self::allowed_html() ) : '',
				'ratio'      => isset( $part['ratio'] ) ? sanitize_text_field( (string) $part['ratio'] ) : '',
				'ratioSub'   => isset( $part['ratioSub'] ) ? sanitize_text_field( (string) $part['ratioSub'] ) : '',
				'ratioLabel' => isset( $part['ratioLabel'] ) ? sanitize_text_field( (string) $part['ratioLabel'] ) : '',
				'tds'        => isset( $part['tds'] ) ? sanitize_text_field( (string) $part['tds'] ) : '',
				'tdsLabel'   => isset( $part['tdsLabel'] ) ? sanitize_text_field( (string) $part['tdsLabel'] ) : '',
				'elements'   => $elements,
			);
			if ( count( $out ) >= 12 ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Image URLs (absolute or relative), capped at 20.
	 *
	 * @param mixed $images Raw images.
	 * @return string[]
	 */
	private static function sanitize_images( $images ) {
		$out = array();
		foreach ( (array) $images as $img ) {
			$url = esc_url_raw( (string) $img );
			if ( $url ) {
				$out[] = $url;
			}
			if ( count( $out ) >= 20 ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Delete hosted images for a product from disk. Only files inside our own
	 * uploads subdir are touched; relative asset paths (seed defaults) are skipped.
	 *
	 * @param array $data Product data object.
	 * @return void
	 */
	private static function delete_images( $data ) {
		$uploads = wp_upload_dir();
		$basedir = trailingslashit( $uploads['basedir'] );
		$baseurl = trailingslashit( $uploads['baseurl'] );
		$prefix  = $baseurl . self::IMAGE_SUBDIR . '/';

		foreach ( (array) ( isset( $data['images'] ) ? $data['images'] : array() ) as $url ) {
			if ( 0 !== strpos( (string) $url, $prefix ) ) {
				continue;
			}
			$path = wp_normalize_path( $basedir . str_replace( $baseurl, '', (string) $url ) );
			if ( is_file( $path ) ) {
				wp_delete_file( $path );
			}
		}
	}

	/**
	 * MySQL DATETIME → ISO-8601 UTC.
	 *
	 * @param string $mysql_dt DATETIME.
	 * @return string
	 */
	private static function to_iso( $mysql_dt ) {
		$ts = strtotime( (string) $mysql_dt . ' UTC' );
		return $ts ? gmdate( 'Y-m-d\TH:i:s\Z', $ts ) : '';
	}
}
