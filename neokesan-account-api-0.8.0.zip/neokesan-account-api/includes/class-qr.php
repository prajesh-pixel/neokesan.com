<?php
/**
 * Permanent QR slugs for printed product packaging.
 *
 * A QR code is frozen at the moment it is printed, so it must never encode a
 * product URL. It encodes https://neokesan.com/q/<slug>/ instead — a static
 * redirect page on our own domain — and this table is the mapping that page is
 * generated from. Repointing a printed code is then an edit to `target`, not a
 * reprint of the packaging.
 *
 * Two rules make the mapping safe, and both are the reason this is a separate
 * table rather than columns on neokesan_products:
 *
 *   - Slugs are never reused. This table is the permanent record of every slug
 *     ever issued, so a code printed in 2026 can never silently become a
 *     different product in 2028.
 *   - Deleting a product retires its QR, never deletes it. The product row is
 *     hard-deleted, so it could not remember its own slug — and a retired code
 *     sends scanners to the homepage rather than a dead page.
 *
 * No image is stored here. The QR image is a pure function of slug → target and
 * is regenerated on demand by assets/qr-render.js, in the browser and in CI.
 * Same convention as Neokesan_Products::registry(): derived, never stored.
 *
 * @package neokesan-account-api
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

/**
 * QR slug registry: slug → target, plus the permanent slug history.
 */
class Neokesan_QR {

	const DB_VERSION = 1;
	const DB_OPTION  = 'neokesan_qr_db_version';

	/**
	 * Hosts a QR target is allowed to point at. Anything else is rejected by
	 * sanitize_target() — `target` is admin-editable and rendered into a
	 * redirect page, so an unrestricted value would turn the admin panel into
	 * an open-redirect generator.
	 */
	const ALLOWED_HOSTS = array( 'neokesan.com', 'www.neokesan.com', 'shop.neokesan.com' );

	const FALLBACK_TARGET = '/';

	/**
	 * Table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'neokesan_qr';
	}

	/**
	 * Create the QR table. Safe to call repeatedly — dbDelta diffs.
	 *
	 * @return void
	 */
	public static function maybe_create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$table   = self::table();

		// dbDelta quirks that silently break it: two spaces after PRIMARY KEY,
		// KEY/UNIQUE KEY (never INDEX), no trailing comma, id first, and column
		// type strings byte-identical across runs.
		//
		// `target` is VARCHAR rather than TEXT because MySQL < 8.0.13 rejects
		// DEFAULT on TEXT columns, and dbDelta round-trips defaults. Both
		// product_key and qr_slug are UNIQUE: qr_slug is the permanent slug
		// history, and a unique product_key makes two rows for one product
		// structurally impossible.
		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			qr_slug VARCHAR(80) NOT NULL,
			product_key VARCHAR(60) NOT NULL,
			target VARCHAR(255) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY qr_slug (qr_slug),
			UNIQUE KEY product_key (product_key)
		) {$charset};";

		dbDelta( $sql );
	}

	/**
	 * Apply schema upgrades when needed. Cheap when current: returns immediately
	 * once the recorded version matches.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( (int) get_option( self::DB_OPTION, 0 ) >= self::DB_VERSION ) {
			return;
		}
		self::maybe_create_table();
		self::backfill();
		update_option( self::DB_OPTION, self::DB_VERSION );
	}

	/**
	 * Give every existing product a QR row. Mandatory, not a nicety:
	 * Neokesan_Products::seed_defaults_if_empty() writes rows with a raw
	 * $wpdb->insert and never passes through insert(), so on a fresh install the
	 * seeded catalog would otherwise have no QR rows at all.
	 *
	 * @return void
	 */
	public static function backfill() {
		// get_all() with no filter returns every status, drafts included. Drafts
		// get a slug reserved here even though they are never published to q/,
		// so the slug cannot be taken by another product in the meantime.
		foreach ( Neokesan_Products::get_all() as $row ) {
			self::ensure( $row->product_key );
		}
	}

	/**
	 * The slug a product is printed under, creating the row if this is the first
	 * time we have seen the product. Idempotent.
	 *
	 * @param string $product_key Product key.
	 * @return string The slug, or '' if the row could not be created.
	 */
	public static function ensure( $product_key ) {
		$key = sanitize_key( (string) $product_key );
		if ( '' === $key ) {
			return '';
		}

		$existing = self::get_by_key( $key );
		if ( $existing ) {
			// A product that was deleted and later re-created keeps the slug it
			// was already printed under. Minting a fresh one would strand the
			// printed code forever, which is the one failure that matters.
			if ( 'active' !== $existing->status ) {
				self::update_row( $existing->qr_slug, array( 'status' => 'active' ) );
			}
			return $existing->qr_slug;
		}

		global $wpdb;
		$table = self::table();
		$now   = current_time( 'mysql' );

		// Two attempts: qr_slug is UNIQUE, so a concurrent insert can take the
		// slug between minting it and writing the row.
		for ( $attempt = 0; $attempt < 2; $attempt++ ) {
			$slug = self::mint_slug( $key );
			$ok   = $wpdb->insert(
				$table,
				array(
					'qr_slug'     => $slug,
					'product_key' => $key,
					'target'      => self::default_target( $key ),
					'status'      => 'active',
					'created_at'  => $now,
					'updated_at'  => $now,
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s' )
			);
			if ( false !== $ok ) {
				return $slug;
			}
		}

		return '';
	}

	/**
	 * Retire a product's QR. Never deletes the row — the slug has to stay in the
	 * history so it can never be reissued, and the page has to keep resolving so
	 * already-printed codes land somewhere sensible.
	 *
	 * @param string $product_key Product key.
	 * @return void
	 */
	public static function retire( $product_key ) {
		$key = sanitize_key( (string) $product_key );
		if ( '' === $key ) {
			return;
		}
		$row = self::get_by_key( $key );
		if ( $row ) {
			self::update_row( $row->qr_slug, array( 'status' => 'retired' ) );
		}
	}

	/**
	 * Set a slug's destination. Rejects any target that is not a path on, or an
	 * https URL on, one of ALLOWED_HOSTS.
	 *
	 * @param string $slug   QR slug.
	 * @param string $target New destination.
	 * @return true|WP_Error
	 */
	public static function set_target( $slug, $target ) {
		$slug = sanitize_key( (string) $slug );
		$row  = $slug ? self::get_row( $slug ) : null;
		if ( ! $row ) {
			return new WP_Error(
				'neokesan_not_found',
				'QR code not found.',
				array( 'status' => 404 )
			);
		}

		$clean = self::sanitize_target( $target );
		if ( '' === $clean ) {
			return new WP_Error(
				'neokesan_bad_target',
				'A destination must be a path on neokesan.com or an https://neokesan.com URL.',
				array( 'status' => 400 )
			);
		}

		return self::update_row( $slug, array( 'target' => $clean ) );
	}

	/**
	 * The published slug → target mapping, for the GitHub Action that writes the
	 * q/<slug>/ redirect pages.
	 *
	 * Published means: the product is active, or it was published at some point
	 * and is now archived or deleted. Drafts are absent — they have never
	 * shipped, so no packaging carries their code, and the public products
	 * endpoints deliberately hide them too. Retired and archived entries point
	 * at the homepage: their packaging may well be in someone's hands, but the
	 * product page behind it is gone.
	 *
	 * @return array[] Each entry: slug, key, name, target.
	 */
	public static function all_public() {
		global $wpdb;
		$qr    = self::table();
		$prod  = Neokesan_Products::table();
		$rows  = $wpdb->get_results(
			"SELECT q.qr_slug, q.product_key, q.target, q.status, p.name AS product_name, p.status AS product_status
			 FROM {$qr} q
			 LEFT JOIN {$prod} p ON p.product_key = q.product_key
			 WHERE ( p.status IS NULL OR p.status <> 'draft' )
			 ORDER BY q.qr_slug ASC"
		);

		$items = array();
		foreach ( (array) $rows as $row ) {
			$live = ( 'active' === $row->product_status && 'active' === $row->status );
			$items[] = array(
				'slug'   => $row->qr_slug,
				'key'    => $row->product_key,
				'name'   => $row->product_name ? $row->product_name : $row->product_key,
				'target' => $live ? $row->target : self::FALLBACK_TARGET,
			);
		}
		return $items;
	}

	/**
	 * Every QR row with its product context, for the admin dashboard.
	 *
	 * @return array[]
	 */
	public static function all_admin() {
		global $wpdb;
		$qr   = self::table();
		$prod = Neokesan_Products::table();
		$rows = $wpdb->get_results(
			"SELECT q.qr_slug, q.product_key, q.target, q.status, q.created_at, q.updated_at,
			        p.name AS product_name, p.status AS product_status
			 FROM {$qr} q
			 LEFT JOIN {$prod} p ON p.product_key = q.product_key
			 ORDER BY p.name ASC, q.qr_slug ASC"
		);

		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = array(
				'slug'           => $row->qr_slug,
				'key'            => $row->product_key,
				'name'           => $row->product_name ? $row->product_name : $row->product_key,
				'target'         => $row->target,
				'status'         => $row->status,
				'product_status' => $row->product_status ? $row->product_status : 'deleted',
				'created_at'     => $row->created_at,
				'updated_at'     => $row->updated_at,
			);
		}
		return $items;
	}

	/* ---------------------------------------------------------------------
	 * Internals
	 * ------------------------------------------------------------------ */

	/**
	 * First free slug for a key. Never returns a slug already in the history.
	 *
	 * @param string $key Sanitized product key.
	 * @return string
	 */
	private static function mint_slug( $key ) {
		// Jekyll does not copy files or directories whose name starts with an
		// underscore, so a leading "_" would mint a slug whose page is silently
		// never deployed while the admin panel showed it working.
		$base = ltrim( (string) $key, '_-' );
		if ( '' === $base ) {
			$base = 'qr';
		}
		$base = substr( $base, 0, 70 );

		$slug = $base;
		$n    = 1;
		while ( self::slug_exists( $slug ) ) {
			$n++;
			$slug = $base . '-' . $n;
		}
		return $slug;
	}

	/**
	 * Where a product's code points when nobody has changed it: its own page.
	 *
	 * @param string $key Product key.
	 * @return string
	 */
	private static function default_target( $key ) {
		return '/product.html?key=' . rawurlencode( $key );
	}

	/**
	 * Restrict a destination to our own site. Returns '' if it is anything else.
	 *
	 * @param string $target Raw target.
	 * @return string Sanitized target, or '' if rejected.
	 */
	private static function sanitize_target( $target ) {
		$target = trim( (string) $target );
		if ( '' === $target ) {
			return '';
		}

		if ( preg_match( '#^[a-z][a-z0-9+.-]*:#i', $target ) ) {
			$parts  = wp_parse_url( $target );
			$scheme = isset( $parts['scheme'] ) ? strtolower( $parts['scheme'] ) : '';
			$host   = isset( $parts['host'] ) ? strtolower( $parts['host'] ) : '';
			if ( 'https' !== $scheme || ! in_array( $host, self::ALLOWED_HOSTS, true ) ) {
				return '';
			}
			return esc_url_raw( $target );
		}

		// "//evil.com" is protocol-relative — a scheme-less absolute URL.
		if ( 0 === strpos( $target, '//' ) ) {
			return '';
		}
		if ( '/' !== substr( $target, 0, 1 ) ) {
			return '';
		}

		return substr( $target, 0, 255 );
	}

	/**
	 * One row by product key.
	 *
	 * @param string $key Product key.
	 * @return object|null
	 */
	private static function get_by_key( $key ) {
		global $wpdb;
		$table = self::table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE product_key = %s LIMIT 1", $key ) );
	}

	/**
	 * One row by slug.
	 *
	 * @param string $slug QR slug.
	 * @return object|null
	 */
	private static function get_row( $slug ) {
		global $wpdb;
		$table = self::table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE qr_slug = %s LIMIT 1", $slug ) );
	}

	/**
	 * Whether a slug is already in the permanent history.
	 *
	 * @param string $slug Candidate slug.
	 * @return bool
	 */
	private static function slug_exists( $slug ) {
		global $wpdb;
		$table = self::table();
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE qr_slug = %s LIMIT 1", $slug ) );
	}

	/**
	 * Update columns on a QR row by slug.
	 *
	 * @param string $slug   QR slug.
	 * @param array  $fields Column → value map.
	 * @return true|WP_Error
	 */
	private static function update_row( $slug, $fields ) {
		global $wpdb;
		$table                = self::table();
		$fields['updated_at'] = current_time( 'mysql' );

		$result = $wpdb->update(
			$table,
			$fields,
			array( 'qr_slug' => $slug ),
			array_fill( 0, count( $fields ), '%s' ),
			array( '%s' )
		);

		if ( false === $result ) {
			return new WP_Error(
				'neokesan_db_error',
				'Could not update the QR code.',
				array( 'status' => 500 )
			);
		}
		return true;
	}

	/* ---------------------------------------------------------------------
	 * REST
	 * ------------------------------------------------------------------ */

	/**
	 * Register the QR routes.
	 *
	 * @return void
	 */
	public static function register_routes() {
		// Public: the GitHub Action that writes q/<slug>/ has no credential and
		// must not need one. Nothing here is secret — product keys and the URLs
		// they resolve to are already public on the site.
		register_rest_route(
			'neokesan/v1',
			'/qr-registry',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'registry' ),
					'permission_callback' => '__return_true',
				),
			)
		);

		register_rest_route(
			'neokesan/v1',
			'/admin/qr',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'list_admin' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_admin' ),
				),
			)
		);

		register_rest_route(
			'neokesan/v1',
			'/admin/qr/(?P<slug>[a-z0-9_-]+)',
			array(
				array(
					'methods'             => 'PUT',
					'callback'            => array( __CLASS__, 'update' ),
					'permission_callback' => array( 'Neokesan_Auth', 'require_admin' ),
				),
			)
		);
	}

	/**
	 * GET /qr-registry — the mapping the sync action renders into redirect pages.
	 *
	 * Returns an envelope rather than a bare array on purpose. A bare [] cannot
	 * be told apart from a failed request, and the sync action treats an empty
	 * result as a reason to prune — which would delete every printed code's
	 * redirect page. `ok: true` with `count: 0` is an explicit, trustworthy
	 * "there are genuinely no codes".
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function registry( $request ) {
		// This is live database state behind a CDN that caches GETs for days,
		// and it is fetched without credentials, so it gets no cache-buster of
		// its own. Refuse to be cached.
		nocache_headers();

		$items = self::all_public();
		return rest_ensure_response(
			array(
				'ok'           => true,
				'count'        => count( $items ),
				'generated_at' => current_time( 'mysql' ),
				'items'        => $items,
			)
		);
	}

	/**
	 * GET /admin/qr — every row with product context.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function list_admin( $request ) {
		$items = self::all_admin();
		return rest_ensure_response(
			array(
				'ok'    => true,
				'count' => count( $items ),
				'items' => $items,
			)
		);
	}

	/**
	 * PUT /admin/qr/{slug} — change where a printed code points.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function update( $request ) {
		$slug   = sanitize_key( (string) $request['slug'] );
		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		if ( ! isset( $params['target'] ) ) {
			return new WP_Error(
				'neokesan_target_required',
				'A destination is required.',
				array( 'status' => 400 )
			);
		}

		$result = self::set_target( $slug, $params['target'] );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			array(
				'ok'    => true,
				'slug'  => $slug,
				'items' => self::all_admin(),
			)
		);
	}
}
