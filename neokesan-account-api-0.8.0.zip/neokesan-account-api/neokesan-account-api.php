<?php
/**
 * Plugin Name:       neoKesan Account API
 * Description:       Headless customer-account API for the neoKesan static site. JWT bearer auth, OTP + Google login, profile + orders endpoints, CORS for neokesan.com.
 * Version:           0.8.0
 * Requires PHP:      7.4
 * Author:            neoKesan
 * Text Domain:       neokesan-account-api
 *
 * @package neokesan-account-api
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'NEOKESAN_ACCOUNT_API_VERSION', '0.8.0' );
define( 'NEOKESAN_ACCOUNT_API_DIR', plugin_dir_path( __FILE__ ) );

require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-jwt.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-auth.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-cors.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-otp.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-google.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-profile.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-orders.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-dev-token.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-quiz.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-product-view.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-admin.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-products.php';
require_once NEOKESAN_ACCOUNT_API_DIR . 'includes/class-qr.php';

/**
 * Register all REST routes for the plugin.
 *
 * @return void
 */
function neokesan_register_routes() {
	Neokesan_Profile::register_routes();
	Neokesan_Orders::register_routes();
	Neokesan_OTP::register_routes();
	Neokesan_Google::register_routes();
	Neokesan_Dev_Token::register_routes();
	Neokesan_Quiz::register_routes();
	Neokesan_Product_View::register_routes();
	Neokesan_Admin::register_routes();
	Neokesan_Products::register_routes();
	Neokesan_QR::register_routes();
}
add_action( 'rest_api_init', 'neokesan_register_routes' );

// Create + seed the products table on activation, and on every admin load as the
// upgrade safety net (activation won't re-fire on an already-active plugin).
register_activation_hook( __FILE__, array( 'Neokesan_Products', 'maybe_upgrade' ) );
register_activation_hook( __FILE__, array( 'Neokesan_QR', 'maybe_upgrade' ) );
add_action( 'admin_init', array( 'Neokesan_Products', 'maybe_upgrade' ) );
add_action( 'admin_init', array( 'Neokesan_QR', 'maybe_upgrade' ) );

// admin_init does NOT fire on a REST request — wp-json goes index.php → wp() →
// parse_request → rest_api_loaded(). So without these, a plugin updated on a
// site nobody logs into would have no QR table the first time the unattended
// sync workflow calls /qr-registry. A missing table reads as "no QR codes",
// and the sync treats that as a reason to delete every redirect page.
//
// Order matters: Neokesan_QR::backfill() reads the products table, so products
// must upgrade first. Same priority, so this is registration order.
add_action( 'rest_api_init', array( 'Neokesan_Products', 'maybe_upgrade' ) );
add_action( 'rest_api_init', array( 'Neokesan_QR', 'maybe_upgrade' ) );
