# neoKesan Account API (WP plugin)

Headless customer-account API for the neoKesan static site. The early releases added JWT
bearer authentication, CORS for the static site, `/profile`, `/orders` and `/dev-token`,
then **OTP login** (`/otp/send`, `/otp/verify`), then **Google sign-in** (`/google` — the
ID token is verified **server-side**, signature + aud/iss/exp/email_verified, and only then
find-or-creates the user and issues the same JWTs), then the **garden quiz** (`/quiz`,
`/quiz/click` — every completed attempt is stored with all four answers, the product
recommendation is computed server-side from the answer key, and buy-on-Amazon clicks are
logged).

The later releases moved the catalog itself into WordPress: the **product catalog** (the
`{prefix}neokesan_products` table, its public endpoints, and the admin CRUD + image upload
behind `admin.html`), **analytics** (`/product-view` plus the admin-only `/admin/stats` and
`/admin/users` dashboards), and — new in 0.8.0 — **permanent QR slugs** (`/qr-registry`,
`/admin/qr`) that let a code printed on packaging outlive the URL it points at. Later
versions wire up the cart and headless checkout.

Version: 0.8.0 · Requires PHP 7.4+

---

## Install

1. Copy the `neokesan-account-api` folder into `wp-content/plugins/` on
   `shop.neokesan.com`.
2. Activate **neoKesan Account API** in the WordPress admin (Plugins → Installed Plugins).
3. Add the constants below to `wp-config.php`.

### wp-config.php constants

```php
// REQUIRED — JWT signing secret. Generate a long random string, e.g.
// `php -r "echo bin2hex(random_bytes(32));"`
define('NEOKESAN_JWT_SECRET', 'replace-with-a-long-random-secret');

// DEV ONLY — enables the /dev-token endpoint used for curl testing below.
// Remove (or set false) in production.
define('NEOKESAN_ACCOUNT_API_DEV', true);
// DEV ONLY — secret value for the X-Neokesan-Dev-Secret header.
define('NEOKESAN_DEV_SECRET', 'replace-with-a-different-long-random-secret');

// Google sign-in — your Google OAuth 2.0 Client ID (the "audience").
// Create one at https://console.cloud.google.com/apis/credentials.
// Sign-in stays disabled (endpoint returns 503) until this is set.
define('NEOKESAN_GOOGLE_CLIENT_ID', '1234567890-abc...apps.googleusercontent.com');

// Optional — additional comma-separated Client IDs if you have more than one
// (e.g. a separate one per localhost port while developing). Merged with the above.
// define('NEOKESAN_GOOGLE_CLIENT_IDS', '1111-aaaa.apps.googleusercontent.com,2222-bbbb.apps.googleusercontent.com');

// Optional — comma-separated override of the allowed origins.
// Defaults: https://neokesan.com, https://www.neokesan.com, localhost dev ports.
// define('NEOKESAN_CORS_ORIGINS', 'https://neokesan.com,http://localhost:5500');
```

If `NEOKESAN_JWT_SECRET` is not set, the plugin falls back to
`JWT_AUTH_SECRET_KEY`, then `SECURE_AUTH_KEY`, then `AUTH_KEY`, then `wp_salt('auth')`.

> **DEV echoes:** while `NEOKESAN_ACCOUNT_API_DEV` is `true`, `/otp/send` echoes the
> generated code as `dev_code` in the response (and logs it) so the flow can be tested
> before real SMTP is configured, and `/google` echoes the verified token claims as
> `dev_claims`. The plugin still attempts `wp_mail()` every time. Remove the DEV
> constants before production.

## Endpoints

All routes are namespaced `/wp-json/neokesan/v1/`. Replace `your-host` with the shop.

| Route | Method | Auth | Purpose |
|---|---|---|---|
| `/otp/send` | POST | none (public) | Request a 6-digit login code by email (rate-limited) |
| `/otp/verify` | POST | none (public) | Verify a code → returns a JWT |
| `/google` | POST | none (public) | Google sign-in: verify an ID token → returns a JWT |
| `/profile` | GET | Bearer token | Fetch current user's profile + grower fields |
| `/profile` | POST | Bearer token | Update profile fields |
| `/orders` | GET | Bearer token | Current user's WooCommerce orders |
| `/quiz` | GET | Bearer token | Attempt count + the user's current recommendation (retake prompt) |
| `/quiz` | POST | Bearer token | Record an attempt (4 answers) + compute the recommendation server-side |
| `/quiz/click` | POST | Bearer token | Log a buy-on-Amazon click for a recommended product |
| `/product-view` | POST | Bearer token | Record a product page view (feeds the analytics tab) |
| `/products` | GET | none (public) | Active products, for the static site |
| `/products` | POST | Admin token | Create a product |
| `/products/{key}` | GET | none (public) | One active product |
| `/products/{key}` | PUT | Admin token | Update a product |
| `/products/{key}` | DELETE | Admin token | Delete a product (retires its QR slug first) |
| `/products/{key}/image` | POST | Admin token | Upload/replace a product image |
| `/admin/products` | GET | Admin token | Every product, drafts included |
| `/admin/stats` | GET | Admin token | Aggregated views / quiz attempts / clicks |
| `/admin/users` | GET | Admin token | The same analytics, per user |
| `/qr-registry` | GET | none (public) | `slug → target` mapping, for the QR sync action |
| `/admin/qr` | GET | Admin token | Every QR slug with its product context |
| `/admin/qr/{slug}` | PUT | Admin token | **Change where a printed code points** |
| `/dev-token` | POST | `X-Neokesan-Dev-Secret` | **DEV ONLY** — mint a JWT for testing |

"Admin token" means a bearer token whose user has the `manage_options` capability
(`Neokesan_Auth::require_admin`), i.e. the WordPress administrator.

### OTP login

```jsonc
// POST /otp/send  {"email": "you@example.com"}
// 200:
{ "status": "code_sent",
  "message": "If this email is registered, a login code has been sent.",
  "expires_in": 600 }

// DEV only — NEOKESAN_ACCOUNT_API_DEV=true adds:
//   "dev_code": "482913",

// POST /otp/verify  {"email": "you@example.com", "code": "482913"}
// 200:
{ "token": "eyJ...", "expires_in": 259200, "user_id": 5, "email": "you@example.com" }
```

- The email does not need to exist: the plugin **find-or-creates** the user
  (username = email local part, role `customer`, random unusable password).
- **Anti-enumeration:** send returns the identical body whether or not the email
  exists, so a caller can't probe which addresses are registered.
- **Rate limits:** 5 send requests per email / 10 per IP per hour (429), 5 verify
  attempts per code (429).
- Codes are stored hashed, expire after 10 minutes, and are single-use.
- The returned JWT is the same bearer token used by `/profile` and `/orders`.

### Google sign-in

The static site gets a Google **ID token** (Google Identity Services) and POSTs it
here; the server verifies it and mints the same JWT.

```jsonc
// POST /google  {"id_token": "eyJhbGciOiJSUzI1NiIsImtpZCI6...eyJpc3MiOiJodHRwczovL2FjY291..."}
// 200:
{ "token": "eyJ...", "expires_in": 259200, "user_id": 7, "email": "you@gmail.com",
  "is_new_user": true }
```

- **Verification is 100% server-side** — no Google secrets ever touch the frontend.
- The RS256 signature is checked locally against Google's public JWKS
  (`https://www.googleapis.com/oauth2/v3/certs`, cached 6h). If local verification
  is unavailable the plugin falls back to Google's `tokeninfo` endpoint (fallback
  only — Google may throttle it). Only `aud`, `iss`, `exp`, `email_verified` and the
  signature being valid are accepted.
- **Account linking by email:** an OTP-created user and a Google login with the same
  email converge on the **same** account (no duplicates). A second Google login with
  the same account returns `is_new_user: false`.
- `email_verified` must be true — an unverified email is never accepted.
- `is_new_user` is `true` only when this login created the WP user just now.
- Before a Client ID is configured the endpoint returns 503 `neokesan_google_not_configured`
  (reachable, testable, but no sign-in).

### Garden quiz & product recommendation

The static site runs a 4-question quiz (`What are you growing?`, `How large is your
growing area?`, `How are you growing your plants?`, `What is your main goal or
challenge?`). Answers are full option-label strings, e.g.
`"A mix of different plants"` or `"Farm or commercial cultivation (More than 100 sq. m)"`.

```jsonc
// GET /quiz  (Bearer token) — attempt count + current recommendation.
// 200:
{ "attempts_count": 2,
  "current": { "attempt_no": 2, "saved_at": "2026-08-09T12:00:00Z",
               "title": "NeoBloom X1, X2 & X3",
               "products": [ { "key": "bloom", "name": "NeoBloom X1, X2 & X3",
                               "asin": "B0HBWZ4G26",
                               "url": "https://www.amazon.in/dp/B0HBWZ4G26",
                               "page": "neobloom.html" } ] } }

// POST /quiz  {"answers": ["...", "...", "...", "..."]}  (Bearer token)
// 200: same summary shape as "current" above.

// POST /quiz/click  {"key": "bloom"}  (Bearer token)
// 200:
{ "saved": true, "picks_count": 1 }
```

- **The recommendation is computed server-side** from the answer key in
  `ref/quiz.txt` — the client never tells the server which product it wants:
  - Q1 `Leafy` → neoFolix; Q1 `Fruiting` → neoBloom; Q1 `Flowers` → neoPonic.
  - Q1 `A mix` → neoBloom, unless Q2 is Farm/commercial → neoBloom **+** neoPonic.
  - Q3 and Q4 are recorded with the attempt but never change the result.
- **All data lives in WP user meta** (the "database"): `neokesan_quiz_attempts`
  (array of attempts — `attempt_no`, all 4 `answers`, `title`, `products`,
  `saved_at`) and `neokesan_quiz_picks` (array of clicks — `key`, `name`, `asin`,
  `url`, `attempt_no`, `clicked_at`). Nothing touches the profile's
  `growing_setup`/`crops` fields.
- `GET /quiz` with zero attempts returns `{"attempts_count":0,"current":null}` —
  the site uses this to decide whether to show the "keep / retake" prompt.
- `POST /quiz` rejects with 400 `neokesan_quiz_incomplete` unless exactly 4
  non-empty answers are sent. `POST /quiz/click` rejects with 400
  `neokesan_quiz_bad_product` for a key outside the product list.

### Profile fields

| JSON key | Notes |
|---|---|
| `first_name`, `last_name` | WP core fields |
| `email` | WP core `user_email`; must be unique (409 if taken) |
| `phone` | meta `neokesan_phone` |
| `dob` | meta `neokesan_dob`; `YYYY-MM-DD`, strict |
| `language` | meta `neokesan_language`; one of English/Hindi/Bengali/Marathi |
| `growing_setup` | meta `neokesan_growing_setup` |
| `crops` | meta `neokesan_crops` |
| `garden_notes` | meta `neokesan_garden_notes` (future use) |

### Permanent QR slugs

A QR code is frozen the moment it is printed, so it must never encode a product URL. It
encodes `https://neokesan.com/q/<slug>/` instead — a static redirect page on our own
domain — and `{prefix}neokesan_qr` is the mapping that page is generated from. Repointing
a printed code is an edit to `target`, not a reprint of the packaging.

Two rules make the mapping safe, and both are why the QR data is its own table rather
than columns on `neokesan_products`:

- **Slugs are never reused.** The table is the permanent record of every slug ever
  issued, so if you delete the product `bloom` and later create another one with that
  key, the new product gets `bloom-2`. A code printed in 2026 can never silently become
  a different product in 2028.
- **Deleting a product retires its QR, never deletes it.** The product row is
  hard-deleted so it could not remember its own slug; the QR row survives with
  `status = 'retired'` and sends scanners to the homepage instead of a dead page.

**No image is ever stored in the database.** The image is a pure function of
`slug → target`, regenerated on demand by `assets/qr-render.js` — in the browser (admin
preview + SVG/PNG download) and in CI (`scripts/sync-qr.js`, which commits
`q/<slug>/index.html`, `q/<slug>/qr.svg` and `q/registry.json` every ~6 h).

```jsonc
// GET /qr-registry  (public, no credential — the GitHub Action has none, and
// nothing here is secret: product keys and their URLs are already public)
// 200:
{ "ok": true, "count": 3, "generated_at": "2026-09-16 09:23:00",
  "items": [ { "slug": "bloom", "key": "bloom", "name": "NeoBloom X1, X2 & X3",
               "target": "/product.html?key=bloom" } ] }

// GET /admin/qr  (Admin token) — adds status + product context, drafts included:
{ "ok": true, "count": 3,
  "items": [ { "slug": "bloom", "key": "bloom", "name": "NeoBloom X1, X2 & X3",
               "target": "/product.html?key=bloom", "status": "active",
               "product_status": "active",
               "created_at": "2026-09-16 09:00:00", "updated_at": "2026-09-16 09:00:00" } ] }

// PUT /admin/qr/bloom  {"target": "/product.html?key=bloom-x2"}  (Admin token)
// 200: { "ok": true, "slug": "bloom", "items": [ /* the refreshed /admin/qr list */ ] }
//      — the list comes back with the write so the dashboard never has to re-fetch.
// 400 neokesan_bad_target — empty, off-site, or not a path on neokesan.com
// 404 neokesan_not_found  — no such slug
```

- `/qr-registry` returns an **envelope**, not a bare array: `[]` cannot be told apart
  from a failed request, and the sync action treats an empty result as a reason to prune
  — which would delete every printed code's redirect page. `ok: true` with `count: 0` is
  a trustworthy "there are genuinely no codes".
- Both **drafts** and (in the registry) **retired/archived** entries are handled
  deliberately. Drafts never shipped, so no packaging carries their code and they are
  absent from `/qr-registry` entirely. Retired and archived entries are present but
  resolve to `/` — that packaging may well be in someone's hands.
- `target` is validated server-side (`sanitize_target`): either a root-relative path
  (`/product.html?key=bloom`) or an `https://` URL on one of the hosts in
  `ALLOWED_HOSTS` (`neokesan.com`, `www.neokesan.com`, `shop.neokesan.com`). Off-site
  links, plain `http://`, protocol-relative `//evil.com`, `javascript:`, bare words and
  host-prefix spoofs like `https://neokesan.com.evil.com/` are all rejected with 400.
- Changing a target takes effect on the live site after the next sync (~6 h), because
  the redirect page is a committed file. The **admin preview and downloads are
  immediate** — they render from the same encoder in the browser — so a brand-new
  product can be printed before any sync runs.

## curl test steps

These work over the command line — no WordPress nonce required, because bearer
tokens bypass cookie checks.

```bash
BASE="https://your-host"

# 1. Mint a dev token for user ID 1 (the admin user).
curl -s -X POST "$BASE/wp-json/neokesan/v1/dev-token" \
  -H "Content-Type: application/json" \
  -H "X-Neokesan-Dev-Secret: replace-with-your-dev-secret" \
  -d '{"user_id":1}'

#    → {"token":"eyJ...","expires_in":259200,"user_id":1,"email":"...","note":"DEV ONLY ..."}

# 2. Read the profile with the token.
TOKEN="paste-token-here"
curl -s "$BASE/wp-json/neokesan/v1/profile" -H "Authorization: Bearer $TOKEN"

# 3. Update a few profile fields.
curl -s -X POST "$BASE/wp-json/neokesan/v1/profile" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"first_name":"Test","language":"English","growing_setup":"DWC / NFT","crops":"basil, mint"}'

# 4. Read orders (returns woocommerce:false gracefully if WC is inactive).
curl -s "$BASE/wp-json/neokesan/v1/orders" -H "Authorization: Bearer $TOKEN"

# 5. OPTIONS preflight (the static site sends this before every cross-origin call).
curl -s -i -X OPTIONS "$BASE/wp-json/neokesan/v1/profile" \
  -H "Origin: https://neokesan.com" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: Authorization, Content-Type"
#    → HTTP/1.1 204 with Access-Control-Allow-Origin: https://neokesan.com etc.
```

### OTP login test (DEV mode)

```bash
# 6. Request a login code (DEV mode echoes dev_code; same 200 body for any email).
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/send" \
  -H "Content-Type: application/json" \
  -d '{"email":"grower@example.com"}'
#    → {"status":"code_sent","message":"...","expires_in":600,"dev_code":"123456",...}

# 7. Verify with a WRONG code → 400 neokesan_otp_invalid.
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/verify" \
  -H "Content-Type: application/json" \
  -d '{"email":"grower@example.com","code":"000000"}'

# 8. Verify with the dev_code → real JWT.
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/verify" \
  -H "Content-Type: application/json" \
  -d '{"email":"grower@example.com","code":"123456"}'
#    → {"token":"eyJ...","expires_in":259200,"user_id":N,"email":"grower@example.com"}

# 9. Use that token on /profile (token was a fresh find-or-create user).
TOKEN="paste-token-here"
curl -s "$BASE/wp-json/neokesan/v1/profile" -H "Authorization: Bearer $TOKEN"
```

Expected failure checks:

```bash
# No token → 401.
curl -s "$BASE/wp-json/neokesan/v1/profile"

# Wrong dev secret → 403.
curl -s -X POST "$BASE/wp-json/neokesan/v1/dev-token" \
  -H "Content-Type: application/json" \
  -H "X-Neokesan-Dev-Secret: wrong" \
  -d '{"user_id":1}'

# Missing/invalid OTP email → 400 (same for everyone).
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/send" \
  -H "Content-Type: application/json" \
  -d '{"email":"not-an-email"}'

# No pending code → 400 neokesan_otp_no_code.
curl -s -X POST "$BASE/wp-json/neokesan/v1/otp/verify" \
  -H "Content-Type: application/json" \
  -d '{"email":"nobody@example.com","code":"000000"}'

# Rate limit: 5+ sends on the same email in an hour → 429 neokesan_otp_limit.
for i in 1 2 3 4 5 6; do
  curl -s -o /dev/null -w "%{http_code}\n" -X POST "$BASE/wp-json/neokesan/v1/otp/send" \
    -H "Content-Type: application/json" -d '{"email":"grower@example.com"}'
done
#    → 200 200 200 200 200 429
```

### Quiz test

```bash
# 20. GET /quiz with no attempts → attempts_count 0, current null.
curl -s "$BASE/wp-json/neokesan/v1/quiz" -H "Authorization: Bearer $TOKEN"

# 21. POST a completed quiz (mix + commercial → NeoBloom + NeoPonic).
curl -s -X POST "$BASE/wp-json/neokesan/v1/quiz" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"answers":["A mix of different plants",
                  "Farm or commercial cultivation (More than 100 sq. m)",
                  "Hydroponics",
                  "I want faster and healthier plant growth."]}'
#    → 200 {"attempt_no":1,"saved_at":"...","title":"NeoBloom X1, X2 & X3 + NeoPonic A & B","products":[...]}

# 22. GET /quiz again → attempts_count 1, current = the saved recommendation.
curl -s "$BASE/wp-json/neokesan/v1/quiz" -H "Authorization: Bearer $TOKEN"

# 23. Log a buy-on-Amazon click for the recommended product.
curl -s -X POST "$BASE/wp-json/neokesan/v1/quiz/click" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"key":"bloom"}'
#    → 200 {"saved":true,"picks_count":1}

# 24. Incomplete answers → 400 neokesan_quiz_incomplete.
curl -s -X POST "$BASE/wp-json/neokesan/v1/quiz" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"answers":["A mix of different plants"]}'

# 25. Unknown product key → 400 neokesan_quiz_bad_product.
curl -s -X POST "$BASE/wp-json/neokesan/v1/quiz/click" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"key":"nope"}'

# 26. No token → 401 (same as /profile).
curl -s "$BASE/wp-json/neokesan/v1/quiz"
```

### Google sign-in test (no real token needed)

Until a real Google token is available the endpoint is still fully testable:

```bash
# 10. Missing token → 400 neokesan_google_missing_token.
curl -s -X POST "$BASE/wp-json/neokesan/v1/google" -H "Content-Type: application/json" -d '{}'

# 11. Not configured (no NEOKESAN_GOOGLE_CLIENT_ID yet) → 503.
curl -s -X POST "$BASE/wp-json/neokesan/v1/google" \
  -H "Content-Type: application/json" -d '{"id_token":"garbage"}'

# 12. With a (placeholder) Client ID set, garbage and a.b.c → 400 bad_token,
#     because the alg/kid header gate rejects them before any network call.
curl -s -X POST "$BASE/wp-json/neokesan/v1/google" \
  -H "Content-Type: application/json" -d '{"id_token":"garbage"}'
curl -s -X POST "$BASE/wp-json/neokesan/v1/google" \
  -H "Content-Type: application/json" -d '{"id_token":"a.b.c"}'

# 13. Self-contained HS256 rejection: mint a dev token (an HS256 JWT) and POST
#     it — must be 400 bad_token (we only accept RS256 ID tokens from Google).
TOKEN=$(curl -s -X POST "$BASE/wp-json/neokesan/v1/dev-token" \
  -H "Content-Type: application/json" \
  -H "X-Neokesan-Dev-Secret: replace-with-your-dev-secret" \
  -d '{"user_id":1}' | python -c "import sys,json;print(json.load(sys.stdin)['token'])")
curl -s -X POST "$BASE/wp-json/neokesan/v1/google" \
  -H "Content-Type: application/json" -d "{\"id_token\":\"$TOKEN\"}"
#    → 400 neokesan_google_bad_token (alg is HS256, not RS256)

# 14. CORS preflight on the new route → 204 with Access-Control-Allow-Origin.
curl -s -i -X OPTIONS "$BASE/wp-json/neokesan/v1/google" \
  -H "Origin: https://neokesan.com" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: Authorization, Content-Type"
```

With a real Client ID + a genuine token the happy path returns a 200 with
`{token, expires_in, user_id, email, is_new_user}` exactly like `/otp/verify`.

### QR test

The registry is public, so step 27 needs no token at all — that is the whole point of it.

```bash
# 27. Public registry — no token, because the GitHub Action that consumes it has
#     no credential and must not need one.
curl -s "$BASE/wp-json/neokesan/v1/qr-registry"
#    → {"ok":true,"count":3,"generated_at":"...","items":[
#         {"slug":"bloom","key":"bloom","name":"...","target":"/product.html?key=bloom"}, ...]}

# 28. Admin list needs a token → 401 without one.
curl -s "$BASE/wp-json/neokesan/v1/admin/qr"
TOKEN="paste-an-admin-token-here"
curl -s "$BASE/wp-json/neokesan/v1/admin/qr" -H "Authorization: Bearer $TOKEN"
#    → {"ok":true,"count":3,"items":[{"slug":"bloom",...,"status":"active",
#         "product_status":"active","created_at":"...","updated_at":"..."}, ...]}

# 29. Repoint an existing code (the whole feature, in one command).
curl -s -X PUT "$BASE/wp-json/neokesan/v1/admin/qr/bloom" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"target":"/product.html?key=bloom-x2"}'
#    → {"ok":true,"slug":"bloom","items":[...]} and neokesan.com/q/bloom
#      now redirects to the new target after the next sync (~6 h).

# 30. Rejected targets → 400 neokesan_bad_target (all four fail the same way).
for T in 'https://evil.com/x' '//evil.com/x' 'javascript:alert(1)' 'product.html' \
         'https://neokesan.com.evil.com/' 'http://neokesan.com/x' ''; do
  curl -s -X PUT "$BASE/wp-json/neokesan/v1/admin/qr/bloom" \
    -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    -d "{\"target\":\"$T\"}" | head -c 80; echo
done

# 31. Unknown slug → 404 neokesan_not_found.
curl -s -X PUT "$BASE/wp-json/neokesan/v1/admin/qr/no-such-slug" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"target":"/"}'
```

To rebuild the committed redirect pages by hand (the Action does this on a cron):

```bash
node scripts/sync-qr.js          # writes q/<slug>/index.html + qr.svg + registry.json
```

It **exits non-zero and writes nothing** if the fetch fails or comes back empty, so a
WordPress outage can never wipe the pages that printed codes depend on.

## Troubleshooting

- **401 on dev-token with correct secret**: confirm `NEOKESAN_ACCOUNT_API_DEV` is `true`
  and the plugin is active. If the route does not exist, WordPress returns a 404.
- **`Access-Control-Allow-Origin` missing**: the origin must be in the allowlist
  exactly (scheme + host + port, no trailing slash). Check your localhost port matches.
- **PHP fatal on plugin activation**: confirm PHP ≥ 7.4 (e.g. `php -v` on the server).
- **Token works in curl but not the browser**: the browser sends a preflight first;
  confirm step 5 passes. Also ensure the secret in `wp-config.php` did not change
  after minting tokens.
- **`dev_code` missing from `/otp/send`**: confirm `NEOKESAN_ACCOUNT_API_DEV` is
  `true` and the plugin re-activated after the update (or hard-refresh — transients
  are per-site, not per-request).
- **OTP email never arrives**: `wp_mail()` needs a working SMTP setup. Until then,
  use `dev_code` from the response / the `error_log`. The API never fails a send
  request just because the mail failed.
- **429 on `/otp/send`**: you hit the 5/hr-per-email or 10/hr-per-IP limit. Wait an
  hour or use a different email/IP; this is expected anti-spam behaviour.
- **404 on `/qr-registry`**: the route does not exist yet — you are running a plugin
  older than 0.8.0. The QR class also needs a `rest_api_init` hook as well as
  `admin_init`; `admin_init` alone does not fire on REST requests, so the table would
  never be created by an API call.
- **QR tab says the code is retired / goes to the homepage**: that is deliberate. Either
  the QR row's `status` is `retired` (the product was deleted) or the product's own
  status is not `active`. `/qr-registry` resolves anything not live to `/`.
- **A repointed QR has not changed on the live site**: the redirect page is a committed
  file, so it updates on the next sync (~6 h) — not immediately. Force it with
  `workflow_dispatch` on the *Sync QR redirect pages* action, or run
  `node scripts/sync-qr.js` locally and commit.
- **GitHub Actions stops syncing**: GitHub disables cron on repos idle for 60 days. Run
  the workflow manually once to restart it. This applies to the price sync too.

## Roadmap

Done: JWT auth + CORS + profile/orders; OTP login; Google sign-in; the garden
quiz and its server-side recommendation; the product catalog, its admin CRUD
and image upload; analytics (`/product-view`, `/admin/stats`, `/admin/users`);
permanent QR slugs with the admin QR tab and the 6-hourly sync action.

Next: wire the frontend `account.html` cart via the WooCommerce Store API;
headless checkout (Razorpay); hardening (remove the DEV constants before
production). See `docs/ACCOUNT-SYSTEM-PLAN.md` at the repo root for the full
plan.
